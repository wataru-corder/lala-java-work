package model;

public class DeleteMutterLogic {

}
