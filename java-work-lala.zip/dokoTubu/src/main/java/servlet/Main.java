package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import model.Mutter;
import model.PostMutterLogic;
import model.User;


@WebServlet("/Main")
public class Main extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//アプリケーションスコープからmitterList(つぶやき)を取り出す
		ServletContext application = this.getServletContext();
		@SuppressWarnings("unchecked")
		List<Mutter> mutterList = (List<Mutter>)application.getAttribute("mutterList");
		
		//アプリケーションスコープにmutterListがなければインスタンス化で作成
		if(mutterList == null) {
			mutterList = new ArrayList<>();
			application.setAttribute("mutterList", mutterList);
		}
		
		//Userを取り出すなければtopにリダイレクト
		HttpSession session = request.getSession();
		User loginUser = (User)session.getAttribute("loginUser");
		
		if(loginUser == null) {
			response.sendRedirect("index.jsp");
			return;
		}
			String path = "WEB-INF/jsp/main.jsp";
			RequestDispatcher d = request.getRequestDispatcher(path);
			d.forward(request, response);
		
				
			
			
		
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("UTF-8");
		String text = request.getParameter("text");
		
		//入力値チェック
		if(text != null && text.length() != 0) {
			
			//アプリケーションスコープからmutterListの呼び出し
			ServletContext application = this.getServletContext();
			@SuppressWarnings("unchecked")
			List<Mutter> mutterList = (List<Mutter>)application.getAttribute("mutterList");
			
			//sessionスコープに接続
			HttpSession session = request.getSession();
			User loginUser = (User)session.getAttribute("loginUser");
			
			//つぶやくリストを作成してつぶやくリストに追加
			UUID uuid = UUID.randomUUID();
			String id = uuid.toString();
			Mutter mutter = new Mutter(loginUser.getName(),text,id);
			PostMutterLogic postMutterLogic = new PostMutterLogic();
			postMutterLogic.execute(mutter, mutterList);
			
			//アプリケーションスコープにつぶやきリストを保存
			application.setAttribute("mutterList", mutterList);
			
			
			
		}else {
			request.setAttribute("errorMsg","つぶやきが入力されてません");
		}
		String path = "WEB-INF/jsp/main.jsp";
		RequestDispatcher d = request.getRequestDispatcher(path);
		d.forward(request, response);
	
	}
	
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	
	
}
