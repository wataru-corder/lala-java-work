package servlet;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import model.Health;
import model.HealthCheckLogic;

/**
 * Servlet implementation class HealthCheck
 */
@WebServlet("/HealthCheck")
public class HealthCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path = "WEB-INF/jsp/healthCheck.jsp";
		RequestDispatcher d = request.getRequestDispatcher(path);
		d.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//入力値の値を取得
		try {
			String weight = request.getParameter("weight");
			String height = request.getParameter("height");
			
			Health h = new Health();
			h.setHeight(Double.parseDouble(height));
			h.setWeight(Double.parseDouble(weight));
			
			HealthCheckLogic healthCheckLogic = new HealthCheckLogic();
			healthCheckLogic.excecute(h);
			
			//リクエストスコープに保存
			request.setAttribute("h",h);
			
			//フォワード
			String path = "WEB-INF/jsp/healthCheckResult.jsp";
			RequestDispatcher d = request.getRequestDispatcher(path);
			d.forward(request, response);
		}catch(NumberFormatException e){
			request.setAttribute("errorMsg","正しい数値を入力してください");
			
			String path = "WEB-INF/jsp/healthCheck.jsp";
			RequestDispatcher d = request.getRequestDispatcher(path);
			d.forward(request, response);
		}
		
	}

}
