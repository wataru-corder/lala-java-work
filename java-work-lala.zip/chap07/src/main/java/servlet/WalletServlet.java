package servlet;

import java.io.IOException;
import java.util.Random;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import model.Wallet;

/**
 * Servlet implementation class WalletServlet
 */
@WebServlet("/WalletServlet")
public class WalletServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int r = new Random().nextInt(1000);
		
		Wallet w = new Wallet(r);
		
		request.setAttribute("wallet", w);
		
		String path = "";
		
		if(r % 2 == 0) {
			path = "WEB-INF/jsp/wallet.jsp";
		}else {
			path = "WEB-INF/jsp/wallet2.jsp";
		}
		RequestDispatcher d = request.getRequestDispatcher(path);
		d.forward(request, response);
	}


}
