package model;

import java.io.Serializable;

public class Wallet implements Serializable{
	private int money;
	
	public Wallet() {}
	
	public Wallet(int money) {this.money =  money;}
	
	public int getWallet() {return money;}
	
	public void setWallet(int money) {this.money = money;}
	
	
}
