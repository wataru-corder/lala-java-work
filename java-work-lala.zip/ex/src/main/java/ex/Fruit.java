package ex;

public class Fruit {

}
