package model;

import java.io.Serializable;

public class Mutter implements Serializable{
	private String useName;
	private String text;
	
	public Mutter(String useName, String text) {
		this.useName = useName;
		this.text = text;
	}
	public String getUseName() {
		return useName;
	}
	public String getText() {
		return text;
	}
	
	
}
