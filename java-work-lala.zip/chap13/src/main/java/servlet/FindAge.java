package servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import model.Employee;
import model.GetListByAgeLogic;


@WebServlet("/FindAge")
public class FindAge extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	    String ageStr = request.getParameter("age");
	    int age = 0;
	    try {
	    	age = Integer.parseInt(ageStr);
	    }catch(NumberFormatException e){
	    	request.setAttribute("error", "年齢には数字を入力してください");
	    	String path = "WEB-INF/jsp/list.jsp";
	    	request.getRequestDispatcher(path).forward(request, response);
	    	return;
	    }
	  
	   

	    // 検索処理
	    GetListByAgeLogic getListByAgeLogic = new GetListByAgeLogic();
	    List<Employee> empList = getListByAgeLogic.execute(age);

	    // 検索結果をリクエストスコープに保存
	    request.setAttribute("empList", empList);
	    request.setAttribute("searchAge", age);

	    // JSPにフォワード
	    request.getRequestDispatcher("WEB-INF/jsp/list.jsp").forward(request, response);
	}

}
