package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Employee;

public class EmployeesDAO {
	private final String JDBC_URL = 
			"jdbc:h2:tcp://localhost/~/example";
	private final String DB_USER = "sa";
	private final String DB_PASS = "";
	
	public List<Employee> findAll() {
		List<Employee> empList = new ArrayList<>();//Employee生成 List<Employee>に追加
		
		//
		try {
			Class.forName("org.h2.Driver");//h2ドライブの読み込み
		} catch (ClassNotFoundException e) {
			throw new IllegalStateException(
					"JDBC読み込みエラー");
		}
		
		try (Connection conn = DriverManager.getConnection(//接続したらconectionオブジェクトの生成
				JDBC_URL, DB_USER, DB_PASS)) {
			String sql = "SELECT id, name, age FROM employees";
			PreparedStatement pStmt = conn.prepareStatement(sql);//データベースへの接続情報を持っている
			ResultSet rs = pStmt.executeQuery();//実行したデータを取得
			
			while (rs.next()) {//データがあれば(true)以下データを取得
				String id = rs.getString("id");
				String name = rs.getString("name");
				int age = rs.getInt("age");
				Employee employee = new Employee(id, name, age);//1件分のデータを取得
				empList.add(employee);//データを追加
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return empList;//2件文のデータを返す
	}
	
	public List<Employee> findByAge(int ages){
		List<Employee> empList = new ArrayList<>();//Employee生成 List<Employee>に追加
		
		try {
			Class.forName("org.h2.Driver");//h2ドライブの読み込み
		} catch (ClassNotFoundException e) {
			throw new IllegalStateException(
					"JDBC読み込みエラー");
		}
		
		try (Connection conn = DriverManager.getConnection(//接続したらconectionオブジェクトの生成
				JDBC_URL, DB_USER, DB_PASS)) {
			String sql = "SELECT id, name, age FROM employees WHERE age >= ?";
			PreparedStatement pStmt = conn.prepareStatement(sql);//データベースへの接続情報を持っている
			pStmt.setInt(1, ages);
			ResultSet rs = pStmt.executeQuery();//実行したデータを取得
			
			while (rs.next()) {//データがあれば(true)以下データを取得
				String id = rs.getString("id");
				String name = rs.getString("name");
				int age = rs.getInt("age");
				Employee employee = new Employee(id, name, age);//1件分のデータを取得
				empList.add(employee);//データを追加
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return empList;
	}
}
