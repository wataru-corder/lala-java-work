package model;

public class User extends Player{
	
	public User() {
		this("ユーザー");
	}
	
	public User(String name) {
		super(name);
	}

	
}
