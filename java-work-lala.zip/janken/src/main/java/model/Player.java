package model;

public  abstract class Player {
	private String name;
	private int hand;
	private String[] handImg = {
			"<img src=\"images/gu.png\" alt=\"グー\">",
			"<img src=\"images/choki.png\" alt=\"チョキ\">",
			"<img src=\"images/pa.png\" alt=\"パー\">"
	};
	
	public String getHandImg() {
		return handImg[this.hand]; 
	}
	
	public Player() {}
	
	public Player(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public int getHand() {
		return hand;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setHand(int hand) {
		this.hand = hand;
	}
	
	
}
